﻿using System;
using System.IO.Ports;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace VaralInteligenteApp
{
    public partial class MainWindow : Window
    {
        private SerialPort _serialPort;
        private const int LIMITE_CHUVA = 600; // O mesmo limite do código Arduino

        public MainWindow()
        {
            InitializeComponent();
            LoadSerialPorts();
            Closed += MainWindow_Closed; // Garante que a porta será fechada ao sair
        }

        private void LoadSerialPorts()
        {
            string[] ports = SerialPort.GetPortNames();
            CboSerialPorts.ItemsSource = ports;
            if (ports.Length > 0)
            {
                CboSerialPorts.SelectedIndex = 0;
            }
        }

        private void BtnConnect_Click(object sender, RoutedEventArgs e)
        {
            if (CboSerialPorts.SelectedItem == null)
            {
                MessageBox.Show("Nenhuma porta serial selecionada.", "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            string selectedPort = CboSerialPorts.SelectedItem.ToString();
            _serialPort = new SerialPort(selectedPort, 9600); // Baud rate = 9600

            try
            {
                _serialPort.DataReceived += SerialPort_DataReceived;
                _serialPort.Open();

                // Atualiza a UI
                BtnConnect.IsEnabled = false;
                BtnDisconnect.IsEnabled = true;
                CboSerialPorts.IsEnabled = false;
                TxtConnectionStatus.Text = "Conectado";
                TxtConnectionStatus.Foreground = Brushes.Green;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao conectar: {ex.Message}", "Erro de Conexão", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void SerialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                string line = _serialPort.ReadLine();
                Dispatcher.Invoke(() =>
                {
                    // Adiciona a linha completa ao log
                    TxtLog.AppendText(line + Environment.NewLine);
                    TxtLog.ScrollToEnd();

                    // Processa a linha para atualizar a UI
                    ProcessArduinoData(line);
                });
            }
            catch (Exception)
            {
                // Ignorar erros que podem ocorrer ao fechar a porta
            }
        }

        private void ProcessArduinoData(string data)
        {
            // Tenta extrair o valor do sensor
            if (data.Contains("Leitura do Sensor de Chuva: "))
            {
                string valueStr = data.Substring(data.IndexOf(':') + 1).Trim();
                valueStr = valueStr.Split(' ')[0]; // Pega apenas o número

                if (int.TryParse(valueStr, out int sensorValue))
                {
                    TxtSensorValue.Text = sensorValue.ToString();
                    SensorProgressBar.Value = sensorValue;

                    // Atualiza o status do clima baseado no valor
                    if (sensorValue < LIMITE_CHUVA)
                    {
                        TxtClimaStatus.Text = "Chovendo";
                        TxtClimaStatus.Foreground = Brushes.DodgerBlue;
                    }
                    else
                    {
                        TxtClimaStatus.Text = "Tempo Bom";
                        TxtClimaStatus.Foreground = Brushes.Orange;
                    }
                }
            }

            // Atualiza o status do varal
            if (data.Contains("Status: Varal recolhido"))
            {
                TxtVaralStatus.Text = "Recolhido";
                TxtVaralStatus.Foreground = Brushes.Crimson;
            }
            else if (data.Contains("Status: Varal estendido"))
            {
                TxtVaralStatus.Text = "Estendido";
                TxtVaralStatus.Foreground = Brushes.ForestGreen;
            }
        }

        private void BtnDisconnect_Click(object sender, RoutedEventArgs e)
        {
            Disconnect();
        }

        private void Disconnect()
        {
            if (_serialPort != null && _serialPort.IsOpen)
            {
                _serialPort.DataReceived -= SerialPort_DataReceived;
                _serialPort.Close();
                _serialPort.Dispose();
            }

            // Atualiza a UI
            BtnConnect.IsEnabled = true;
            BtnDisconnect.IsEnabled = false;
            CboSerialPorts.IsEnabled = true;
            TxtConnectionStatus.Text = "Desconectado";
            TxtConnectionStatus.Foreground = Brushes.Red;

            // Reseta os valores
            TxtVaralStatus.Text = "---";
            TxtClimaStatus.Text = "---";
            TxtSensorValue.Text = "0";
            SensorProgressBar.Value = 0;
        }

        private void MainWindow_Closed(object sender, EventArgs e)
        {
            Disconnect(); // Garante que a porta seja fechada
        }
    }
}